# Etiquetas
Etiquetas para impresora TA210

Programa simple para impresion de etiquetas en una TA210.

Cuenta con dos pestañas para la impresion de etiquetas seriadas y personalizadas.


Eso es to, eso es to, eso es todo amigos!
